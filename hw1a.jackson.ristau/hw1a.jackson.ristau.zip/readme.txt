compilation:

$ mkdir build
$ cd build
$ cmake ..
$ cmake --build .